#ifndef ARRAYLIB_H
#define ARRAYLIB_H
int maxindex(int arr[], int size);
int minindex(int arr[], int size);
float Average(int arr[], int size);
void displayArray(int arr[], int size);
int reverseArray(int arr[], int size);
void sortArray(int arr[], int size);
int linearSearch(int arr[], int size, int value);
#endif 



