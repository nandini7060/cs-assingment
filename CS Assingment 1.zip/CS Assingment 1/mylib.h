#ifndef MYLIB_H
#define MYLIB_H
int isArmstrong(int num);
int isAdams(int num);
int isPrimePalindrome(int num);
#endif