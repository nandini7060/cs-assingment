 #include"myheader.h"
 int main(){
 
 
 int a[] = {3, 1, 4, 2, 5};
   int n = 5;
   displayArray(a, n);
   printf("Max at index %d\n", maxindex(a,n));
   reverseArray(a,n);
   return 0;
}